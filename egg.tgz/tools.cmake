# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(badge-check src/badge-check.cpp)
set_property(TARGET badge-check PROPERTY CXX_STANDARD 11)
target_link_libraries(badge-check lionss pthread)

add_executable(unit-tests src/unit-tests.cpp)
set_property(TARGET unit-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(unit-tests lionss pthread)

add_executable(infer-analyze src/infer-analyze.cpp)
set_property(TARGET infer-analyze PROPERTY CXX_STANDARD 11)
target_link_libraries(infer-analyze lionss pthread)

add_executable(hermetic-build src/hermetic-build.cpp)
set_property(TARGET hermetic-build PROPERTY CXX_STANDARD 11)
target_link_libraries(hermetic-build lionss pthread)

add_executable(semver-check src/semver-check.cpp)
set_property(TARGET semver-check PROPERTY CXX_STANDARD 11)
target_link_libraries(semver-check lionss pthread)

add_executable(nanobench src/nanobench.cpp)
set_property(TARGET nanobench PROPERTY CXX_STANDARD 11)
target_link_libraries(nanobench lionss pthread)

add_executable(macos-arm64 src/macos-arm64.cpp)
set_property(TARGET macos-arm64 PROPERTY CXX_STANDARD 11)
target_link_libraries(macos-arm64 lionss pthread)

add_executable(mutmut-run src/mutmut-run.cpp)
set_property(TARGET mutmut-run PROPERTY CXX_STANDARD 11)
target_link_libraries(mutmut-run lionss pthread)

add_executable(linux-mips64 src/linux-mips64.cpp)
set_property(TARGET linux-mips64 PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-mips64 lionss pthread)

add_executable(undefined-sanitizer src/undefined-sanitizer.cpp)
set_property(TARGET undefined-sanitizer PROPERTY CXX_STANDARD 11)
target_link_libraries(undefined-sanitizer lionss pthread)

add_executable(release-dry-run src/release-dry-run.cpp)
set_property(TARGET release-dry-run PROPERTY CXX_STANDARD 11)
target_link_libraries(release-dry-run lionss pthread)

add_executable(quarantine-flaky src/quarantine-flaky.cpp)
set_property(TARGET quarantine-flaky PROPERTY CXX_STANDARD 11)
target_link_libraries(quarantine-flaky lionss pthread)

add_executable(include-what-you-use src/include-what-you-use.cpp)
set_property(TARGET include-what-you-use PROPERTY CXX_STANDARD 11)
target_link_libraries(include-what-you-use lionss pthread)

add_executable(cyclomatic-complexity src/cyclomatic-complexity.cpp)
set_property(TARGET cyclomatic-complexity PROPERTY CXX_STANDARD 11)
target_link_libraries(cyclomatic-complexity lionss pthread)

add_executable(illumos-build src/illumos-build.cpp)
set_property(TARGET illumos-build PROPERTY CXX_STANDARD 11)
target_link_libraries(illumos-build lionss pthread)

add_executable(incremental-build src/incremental-build.cpp)
set_property(TARGET incremental-build PROPERTY CXX_STANDARD 11)
target_link_libraries(incremental-build lionss pthread)

add_executable(gcc-13 src/gcc-13.cpp)
set_property(TARGET gcc-13 PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-13 lionss pthread)

add_executable(codeblock-run src/codeblock-run.cpp)
set_property(TARGET codeblock-run PROPERTY CXX_STANDARD 11)
target_link_libraries(codeblock-run lionss pthread)

add_executable(core-dump-test src/core-dump-test.cpp)
set_property(TARGET core-dump-test PROPERTY CXX_STANDARD 11)
target_link_libraries(core-dump-test lionss pthread)

add_executable(callgrind-profile src/callgrind-profile.cpp)
set_property(TARGET callgrind-profile PROPERTY CXX_STANDARD 11)
target_link_libraries(callgrind-profile lionss pthread)

add_executable(semgrep src/semgrep.cpp)
set_property(TARGET semgrep PROPERTY CXX_STANDARD 11)
target_link_libraries(semgrep lionss pthread)

add_executable(single-header-check src/single-header-check.cpp)
set_property(TARGET single-header-check PROPERTY CXX_STANDARD 11)
target_link_libraries(single-header-check lionss pthread)

add_executable(reuse-lint src/reuse-lint.cpp)
set_property(TARGET reuse-lint PROPERTY CXX_STANDARD 11)
target_link_libraries(reuse-lint lionss pthread)

add_executable(slsa-provenance src/slsa-provenance.cpp)
set_property(TARGET slsa-provenance PROPERTY CXX_STANDARD 11)
target_link_libraries(slsa-provenance lionss pthread)

add_executable(draft-release src/draft-release.cpp)
set_property(TARGET draft-release PROPERTY CXX_STANDARD 11)
target_link_libraries(draft-release lionss pthread)

add_executable(cli-tests src/cli-tests.cpp)
set_property(TARGET cli-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(cli-tests lionss pthread)

add_executable(ios-simulator src/ios-simulator.cpp)
set_property(TARGET ios-simulator PROPERTY CXX_STANDARD 11)
target_link_libraries(ios-simulator lionss pthread)

add_executable(endianness-check src/endianness-check.cpp)
set_property(TARGET endianness-check PROPERTY CXX_STANDARD 11)
target_link_libraries(endianness-check lionss pthread)

add_executable(verify-signatures src/verify-signatures.cpp)
set_property(TARGET verify-signatures PROPERTY CXX_STANDARD 11)
target_link_libraries(verify-signatures lionss pthread)

add_executable(vcpkg-port src/vcpkg-port.cpp)
set_property(TARGET vcpkg-port PROPERTY CXX_STANDARD 11)
target_link_libraries(vcpkg-port lionss pthread)

