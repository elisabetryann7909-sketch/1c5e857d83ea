// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("incremental build\n", stdout);
  return lionss_run_workload("incremental-build");
}
