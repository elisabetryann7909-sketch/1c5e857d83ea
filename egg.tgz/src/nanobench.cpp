// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("nanobench"); }
int main(){
  announce();
  return lionss_run_workload("nanobench");
}
