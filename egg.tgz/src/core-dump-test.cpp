// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("core dump test\n", stdout);
  return lionss_run_workload("core-dump-test");
}
